
package net.philippelevis.hypixelskyblock.itemgroup;

import net.philippelevis.hypixelskyblock.item.HyperionItem;
import net.philippelevis.hypixelskyblock.HypixelSkyblockModElements;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemGroup;

@HypixelSkyblockModElements.ModElement.Tag
public class HypixelItemGroup extends HypixelSkyblockModElements.ModElement {
	public HypixelItemGroup(HypixelSkyblockModElements instance) {
		super(instance, 8);
	}

	@Override
	public void initElements() {
		tab = new ItemGroup("tabhypixel") {
			@OnlyIn(Dist.CLIENT)
			@Override
			public ItemStack createIcon() {
				return new ItemStack(HyperionItem.block);
			}

			@OnlyIn(Dist.CLIENT)
			public boolean hasSearchBar() {
				return false;
			}
		};
	}

	public static ItemGroup tab;
}
