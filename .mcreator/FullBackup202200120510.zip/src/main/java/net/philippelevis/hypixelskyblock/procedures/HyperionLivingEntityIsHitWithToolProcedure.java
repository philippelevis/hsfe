package net.philippelevis.hypixelskyblock.procedures;

import net.philippelevis.hypixelskyblock.HypixelSkyblockMod;

import net.minecraft.util.text.StringTextComponent;
import net.minecraft.entity.Entity;

import java.util.Map;

public class HyperionLivingEntityIsHitWithToolProcedure {

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				HypixelSkyblockMod.LOGGER.warn("Failed to load dependency entity for procedure HyperionLivingEntityIsHitWithTool!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		entity.setCustomName(new StringTextComponent("Display name"));
		entity.getPersistentData().putString("id", "minecraft:creeper");
	}
}
