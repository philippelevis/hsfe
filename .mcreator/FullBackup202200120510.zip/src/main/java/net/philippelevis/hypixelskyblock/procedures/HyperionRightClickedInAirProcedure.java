package net.philippelevis.hypixelskyblock.procedures;

import net.philippelevis.hypixelskyblock.enchantment.WithershieldEnchantment;
import net.philippelevis.hypixelskyblock.enchantment.ShadowwarpEnchantment;
import net.philippelevis.hypixelskyblock.enchantment.ImplosionEnchantment;
import net.philippelevis.hypixelskyblock.HypixelSkyblockMod;

import net.minecraft.world.server.ServerWorld;
import net.minecraft.world.IWorld;
import net.minecraft.util.math.RayTraceContext;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.Hand;
import net.minecraft.util.DamageSource;
import net.minecraft.particles.ParticleTypes;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.Entity;
import net.minecraft.enchantment.EnchantmentHelper;

import java.util.stream.Collectors;
import java.util.function.Function;
import java.util.Map;
import java.util.List;
import java.util.Comparator;
import java.util.Collections;

public class HyperionRightClickedInAirProcedure {

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				HypixelSkyblockMod.LOGGER.warn("Failed to load dependency world for procedure HyperionRightClickedInAir!");
			return;
		}
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				HypixelSkyblockMod.LOGGER.warn("Failed to load dependency entity for procedure HyperionRightClickedInAir!");
			return;
		}
		if (dependencies.get("itemstack") == null) {
			if (!dependencies.containsKey("itemstack"))
				HypixelSkyblockMod.LOGGER.warn("Failed to load dependency itemstack for procedure HyperionRightClickedInAir!");
			return;
		}
		IWorld world = (IWorld) dependencies.get("world");
		Entity entity = (Entity) dependencies.get("entity");
		ItemStack itemstack = (ItemStack) dependencies.get("itemstack");
		double x1 = 0;
		double y1 = 0;
		double z1 = 0;
		if (EnchantmentHelper.getEnchantmentLevel(ShadowwarpEnchantment.enchantment, itemstack) >= 1) {
			{
				Entity _ent = entity;
				_ent.setPositionAndUpdate(
						(entity.world.rayTraceBlocks(new RayTraceContext(entity.getEyePosition(1f),
								entity.getEyePosition(1f).add(entity.getLook(1f).x * 8, entity.getLook(1f).y * 8, entity.getLook(1f).z * 8),
								RayTraceContext.BlockMode.OUTLINE, RayTraceContext.FluidMode.NONE, entity)).getPos().getX() + 0.5),
						(entity.world.rayTraceBlocks(new RayTraceContext(entity.getEyePosition(1f),
								entity.getEyePosition(1f).add(entity.getLook(1f).x * 8, entity.getLook(1f).y * 8, entity.getLook(1f).z * 8),
								RayTraceContext.BlockMode.OUTLINE, RayTraceContext.FluidMode.NONE, entity)).getPos().getY() + 1),
						(entity.world.rayTraceBlocks(new RayTraceContext(entity.getEyePosition(1f),
								entity.getEyePosition(1f).add(entity.getLook(1f).x * 8, entity.getLook(1f).y * 8, entity.getLook(1f).z * 8),
								RayTraceContext.BlockMode.OUTLINE, RayTraceContext.FluidMode.NONE, entity)).getPos().getZ() + 0.5));
				if (_ent instanceof ServerPlayerEntity) {
					((ServerPlayerEntity) _ent).connection
							.setPlayerLocation(
									(entity.world.rayTraceBlocks(
											new RayTraceContext(entity.getEyePosition(1f),
													entity.getEyePosition(1f).add(entity.getLook(1f).x * 8, entity.getLook(1f).y * 8,
															entity.getLook(1f).z * 8),
													RayTraceContext.BlockMode.OUTLINE, RayTraceContext.FluidMode.NONE, entity))
											.getPos().getX() + 0.5),
									(entity.world
											.rayTraceBlocks(new RayTraceContext(entity.getEyePosition(1f),
													entity.getEyePosition(1f).add(entity.getLook(1f).x * 8, entity.getLook(1f).y * 8,
															entity.getLook(1f).z * 8),
													RayTraceContext.BlockMode.OUTLINE, RayTraceContext.FluidMode.NONE, entity))
											.getPos().getY() + 1),
									(entity.world.rayTraceBlocks(new RayTraceContext(entity.getEyePosition(1f),
											entity.getEyePosition(1f).add(entity.getLook(1f).x * 8, entity.getLook(1f).y * 8,
													entity.getLook(1f).z * 8),
											RayTraceContext.BlockMode.OUTLINE, RayTraceContext.FluidMode.NONE, entity)).getPos().getZ() + 0.5),
									_ent.rotationYaw, _ent.rotationPitch, Collections.emptySet());
				}
			}
		}
		if (EnchantmentHelper.getEnchantmentLevel(ImplosionEnchantment.enchantment, itemstack) >= 1) {
			if (entity instanceof PlayerEntity) {
				((PlayerEntity) entity).abilities.disableDamage = (true);
				((PlayerEntity) entity).sendPlayerAbilities();
			}
			if (entity instanceof LivingEntity) {
				((LivingEntity) entity).swing(Hand.MAIN_HAND, true);
			}
			if (world instanceof ServerWorld) {
				((ServerWorld) world).spawnParticle(ParticleTypes.EXPLOSION, (entity.getPosX()), (entity.getPosY()), (entity.getPosZ()), (int) 30, 4,
						4, 4, 1);
			}
			{
				List<Entity> _entfound = world
						.getEntitiesWithinAABB(Entity.class,
								new AxisAlignedBB((entity.getPosX()) - (4 / 2d), (entity.getPosY()) - (4 / 2d), (entity.getPosZ()) - (4 / 2d),
										(entity.getPosX()) + (4 / 2d), (entity.getPosY()) + (4 / 2d), (entity.getPosZ()) + (4 / 2d)),
								null)
						.stream().sorted(new Object() {
							Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
								return Comparator.comparing((Function<Entity, Double>) (_entcnd -> _entcnd.getDistanceSq(_x, _y, _z)));
							}
						}.compareDistOf((entity.getPosX()), (entity.getPosY()), (entity.getPosZ()))).collect(Collectors.toList());
				for (Entity entityiterator : _entfound) {
					if (entityiterator instanceof LivingEntity) {
						((LivingEntity) entityiterator).attackEntityFrom(new DamageSource("hyperion").setDamageBypassesArmor(), (float) 1);
					}
					if (entityiterator instanceof PlayerEntity) {
						((PlayerEntity) entityiterator).abilities.disableDamage = ((entityiterator instanceof PlayerEntity)
								? ((PlayerEntity) entityiterator).abilities.isCreativeMode
								: false);
						((PlayerEntity) entityiterator).sendPlayerAbilities();
					}
				}
			}
			if (entity instanceof PlayerEntity) {
				((PlayerEntity) entity).abilities.disableDamage = (false);
				((PlayerEntity) entity).sendPlayerAbilities();
			}
		}
		if (EnchantmentHelper.getEnchantmentLevel(WithershieldEnchantment.enchantment, itemstack) >= 1) {
			System.out.println("hyperion used");
		}
		if (entity instanceof PlayerEntity)
			((PlayerEntity) entity).getCooldownTracker().setCooldown(itemstack.getItem(), (int) 5);
		if (entity instanceof PlayerEntity) {
			((PlayerEntity) entity).abilities.disableDamage = ((entity instanceof PlayerEntity)
					? ((PlayerEntity) entity).abilities.isCreativeMode
					: false);
			((PlayerEntity) entity).sendPlayerAbilities();
		}
	}
}
