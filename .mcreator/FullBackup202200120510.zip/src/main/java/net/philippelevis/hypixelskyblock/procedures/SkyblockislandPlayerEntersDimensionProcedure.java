package net.philippelevis.hypixelskyblock.procedures;

import net.philippelevis.hypixelskyblock.HypixelSkyblockModVariables;
import net.philippelevis.hypixelskyblock.HypixelSkyblockMod;

import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.entity.Entity;

import java.util.Map;
import java.util.Collections;

public class SkyblockislandPlayerEntersDimensionProcedure {

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				HypixelSkyblockMod.LOGGER.warn("Failed to load dependency entity for procedure SkyblockislandPlayerEntersDimension!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		{
			Entity _ent = entity;
			_ent.setPositionAndUpdate(0,
					((entity.getCapability(HypixelSkyblockModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new HypixelSkyblockModVariables.PlayerVariables())).Player_islandSpawn_Y),
					((entity.getCapability(HypixelSkyblockModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new HypixelSkyblockModVariables.PlayerVariables())).Player_islandSpawn_Z));
			if (_ent instanceof ServerPlayerEntity) {
				((ServerPlayerEntity) _ent).connection.setPlayerLocation(0,
						((entity.getCapability(HypixelSkyblockModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new HypixelSkyblockModVariables.PlayerVariables())).Player_islandSpawn_Y),
						((entity.getCapability(HypixelSkyblockModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new HypixelSkyblockModVariables.PlayerVariables())).Player_islandSpawn_Z),
						_ent.rotationYaw, _ent.rotationPitch, Collections.emptySet());
			}
		}
	}
}
